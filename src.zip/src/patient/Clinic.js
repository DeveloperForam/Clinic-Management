import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/clinic.css";

const Clinic = () => {
  const navigate = useNavigate();
  const [clinics, setClinics] = useState([]);
  const [selectedClinic, setSelectedClinic] = useState(null);
  const [doctors, setDoctors] = useState([]);
  const [fadeIn, setFadeIn] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  useEffect(() => {
    setFadeIn(true);
    fetch("http://localhost:5000/api/clinic", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => setClinics(data))
      .catch((error) => console.error("Error fetching clinics:", error));
  }, []);

  useEffect(() => {
    if (selectedClinic) {
      fetch(`http://localhost:5000/api/doctor/list/${selectedClinic}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => setDoctors(data))
        .catch((error) => console.error("Error fetching doctors:", error));
    }
  }, [selectedClinic]);

  const selectDoctor = (doctorId) => {
    fetch(`http://localhost:5000/api/doctor/list/${selectClinic}`, {  // Ensure correct endpoint
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      // .then((data) => setSelectedDoctor(data))
      .then((data) => setSelectedDoctor(data.find((doc) => doc.id === doctorId)))
      .catch((error) => console.error("Error fetching doctor details:", error));

      navigate(`/doctor/${doctorId}`);
  };
  
  return (
    <div className={`clinic-container ${fadeIn ? "fade-in" : ""}`}>
      <h2>
        {selectedClinic
          ? `Doctors in ${clinics.find((c) => c.id === selectedClinic)?.clinic_name}`
          : "Select a Clinic"}
      </h2>

      {!selectedClinic ? (
       <div className="clinic-list">
       {clinics.map((clinic, index) => (
         <div key={clinic.id || index} className="clinic-card">
           <div className="clinic-info">
             <h3>{clinic.clinic_name}</h3>
             <p><strong>Address:</strong> {clinic.address}</p>
             <p><strong>Contact:</strong> {clinic.mobile_no}</p>
             <p><strong>Email:</strong> {clinic.email}</p>
           </div>
           <button
             className="select-clinic-btn"
            //  onClick={() => {
            //    setFadeIn(false);
            //    setTimeout(() => {
            //      setSelectedClinic(clinic.id);
            //      setFadeIn(true);
            //    }, 300);
            //  }}
           >
             Select Doctor
           </button>
         </div>
       ))}
     </div>
      ) : (
        <div>
          <button
            className="back-btn"
            onClick={() => {
              setFadeIn(false);
              setTimeout(() => {
                setSelectedClinic(null);
                setFadeIn(true);
                setDoctors([]);
                setSelectedDoctor(null);
              }, 300);
            }}
          >
            ← Back to Clinics
          </button>
          <div className="doctor-list">
            {doctors.length > 0 ? (
              doctors.map((doctor, index) => (
                <div key={doctor.id || index} className="doctor-card">
                  <h3>{doctor.name}</h3>
                  <p><strong>Clinic:</strong> {doctor.clinic_name}</p>
                  <p><strong>Email:</strong> {doctor.email}</p>
                  <p><strong>Mobile No:</strong> {doctor.mobile_no}</p>
                  <p><strong>Specialization:</strong> {doctor.specialization}</p>
                  <p><strong>Experience:</strong> {doctor.experience} years</p>
                  <p><strong>Gender:</strong> {doctor.gender}</p>
                  <p><strong>Address:</strong> {doctor.address}</p>
                  <button className="select-doctor-btn" onClick={() => selectDoctor(doctor.id)}>
                    Select Doctor
                  </button>
                </div>
              ))
            ) : (
              <p>No doctors found for this clinic.</p>
            )}
          </div>

          {selectedDoctor && (
            <div className="selected-doctor-details">
              <h3>Selected Doctor Details</h3>
              <p><strong>Name:</strong> {selectedDoctor.name}</p>
              <p><strong>Clinic:</strong> {selectedDoctor.clinic_name}</p>
              <p><strong>Email:</strong> {selectedDoctor.email}</p>
              <p><strong>Mobile No:</strong> {selectedDoctor.mobile_no}</p>
              <p><strong>Specialization:</strong> {selectedDoctor.specialization}</p>
              <p><strong>Experience:</strong> {selectedDoctor.experience} years</p>
              <p><strong>Gender:</strong> {selectedDoctor.gender}</p>
              <p><strong>Address:</strong> {selectedDoctor.address}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Clinic;
