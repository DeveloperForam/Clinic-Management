import React, { useState, useEffect } from "react";
import "../styles/dashboard.css";

const API_URL = "http://localhost:5000/api/schedules";

const ManageSchedule = () => {
  const [schedule, setSchedule] = useState([]);
  const [newDay, setNewDay] = useState("");
  const [newTime, setNewTime] = useState("");

  // Fetch schedule list from API
  useEffect(() => {
    fetch(API_URL)
      .then((response) => response.json())
      .then((data) => setSchedule(data))
      .catch((error) => console.error("Error fetching schedules:", error));
  }, []);

  // Add new schedule
  const addSchedule = () => {
    if (newDay && newTime) {
      const newSlot = {
        clinic_id: 3, // Update as required
        doctor_id: 4, // Update as required
        available_days: newDay,
        available_time: newTime,
      };

      fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSlot),
      })
        .then((response) => response.json())
        .then((data) => {
          setSchedule([...schedule, data]);
          setNewDay("");
          setNewTime("");
        })
        .catch((error) => console.error("Error adding schedule:", error));
    }
  };

  // Update schedule
  const updateSchedule = (id) => {
    const updatedTime = prompt("Enter new time:");
    if (updatedTime) {
      fetch(`${API_URL}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ available_time: updatedTime }),
      })
        .then((response) => response.json())
        .then(() => {
          setSchedule(
            schedule.map((slot) =>
              slot.id === id ? { ...slot, available_time: updatedTime } : slot
            )
          );
        })
        .catch((error) => console.error("Error updating schedule:", error));
    }
  };

  // Delete schedule
  const deleteSchedule = (id) => {
    fetch(`${API_URL}/${id}`, { method: "DELETE" })
      .then(() => {
        setSchedule(schedule.filter((slot) => slot.id !== id));
      })
      .catch((error) => console.error("Error deleting schedule:", error));
  };

  return (
    <div className="dashboard-container">
      <h2>Manage Schedule</h2>
      <table className="dashboard-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Doctor</th>
            <th>Clinic</th>
            <th>Available Days</th>
            <th>Available Time</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {schedule.map((slot) => (
            <tr key={slot.id}>
              <td>{slot.id}</td>
              <td>{slot.doctor_name || "Unknown"}</td>
              <td>{slot.clinic_name || "Unknown"}</td>
              <td>{slot.available_days}</td>
              <td>{slot.available_time}</td>
              <td>
                <button onClick={() => updateSchedule(slot.id)}>Edit</button>
                <button onClick={() => deleteSchedule(slot.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="dashboard-content">
        <h3>Add New Schedule</h3>
        <input
          type="text"
          placeholder="Available Days"
          value={newDay}
          onChange={(e) => setNewDay(e.target.value)}
        />
        <input
          type="text"
          placeholder="Available Time"
          value={newTime}
          onChange={(e) => setNewTime(e.target.value)}
        />
        <button onClick={addSchedule} className="dashboard-btn">
          Add Schedule
        </button>
      </div>
    </div>
  );
};

export default ManageSchedule;
